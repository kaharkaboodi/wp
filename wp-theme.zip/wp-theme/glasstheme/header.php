<!DOCTYPE html>
<html lang="en">
    <head>
        <?php wp_head();
        //  echo get_option('phone_number');
        //  echo get_option('email_address');
         
         ?>
        
</head>
<body <?php body_class(); ?>>
   <!-- Header start -->
   <header class="header">
                <div class="container">
                    <div class="row flex-end">
                        <button class="nav-toggler" id="nav-toggler">
                            <span></span>
                        </button>
                        <nav class="nav" id="nav">
                            <div class="nav-inner">
                                    <?php  wp_nav_menu(array(
                                        'primary' => 'test',
                                        'container' => false
                                    ) ) ?>
                                
                            </div>
                        </nav>
                    </div>
                </div>
             </header>     
