<?php
  get_header();
 the_content();
 get_footer()
?>