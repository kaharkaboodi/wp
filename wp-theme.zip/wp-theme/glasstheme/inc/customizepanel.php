<?php
function live_theme_customize($wp_customize){

  $wp_customize->add_panel('diwp_option_panel', array(
 
    'title' => 'edit about & icon & email &...',
    'description' => 'You can changed Socila icons',
    'priority' => 0,
    'capability' => 'edit_theme_options', 
    'theme_supports' => '',
    'active_callback' => ''
));
$wp_customize->add_section( 'diwp_general_option_section', array(
 
  'title' => 'Icons',
  'description' => 'You can changed Socila icons',
  'panel' => 'diwp_option_panel',
  'capability' => 'edit_theme_options',
  'theme_supports' => '',
  'active_callback' => '',
  'description_hidden' => false
));
$wp_customize->add_setting( 'diwp_site_title', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon1_address', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));

$wp_customize->add_setting( 'icon3_address', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon4_address', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon5_address', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon2', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon2_address', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon3', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon4', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_setting( 'icon5', array(
 
  'default' => '',
  'type'      => 'theme_mod', 
  'transport' => 'refresh',  
  'theme_supports' => ''
));
$wp_customize->add_control( 'diwp_site_title', array(
  'label'   => 'Icon and Details',
  'description' => 'Add Icone and details',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_control( 'icon1_address', array(
  'label'   => 'Icon and Details',
  'description' => 'Add your url ',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 

$wp_customize->add_control( 'icon2', array(
  'label'   => 'Icon and Details0',
  'description' => 'Add Icone and details1',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  // 'priority' => 3,
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_control( 'icon2_address', array(
  'label'   => 'Icon and Details',
  'description' => 'Add your url ',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  // 'priority' => 5,
  'input_attrs' => array( 'placeholder' => 'Enter url' )
)); 
$wp_customize->add_control( 'icon3', array(
  'label'   => 'Icon and Details3',
  'description' => 'Add Icone and details',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_control( 'icon3_address', array(
  'label'   => 'Icon and Details3',
  'description' => 'Add your url ',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_control( 'icon4', array(
  'label'   => 'Icon and Details',
  'description' => 'Add Icone and details',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 

$wp_customize->add_control( 'icon4_address', array(
  'label'   => 'Icon and Details',
  'description' => 'Add your url ',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_control( 'icon5', array(
  'label'   => 'Icon and Details',
  'description' => 'Add Icone and details',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_control( 'icon5_address', array(
  'label'   => 'Icon and Details',
  'description' => 'Add your url ',
  'section' => 'diwp_general_option_section',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Enter icon' )
)); 
$wp_customize->add_section('about-mee', array(
  'title'          => ('about edit'),
  'description'    => ('change title and about photo'),
  'panel' => 'diwp_option_panel',
  'capability' => 'edit_theme_options',
  'theme_supports' => '',
  'active_callback' => '',
  'description_hidden' => false,   
),
);
// Image Setting
$wp_customize->add_setting('about-image', array(
  'default' => get_bloginfo('template_directory') . './assets/img/about-img.png',
  'type'    => 'theme_mod',
  'transport' => 'refresh',  
  'theme_supports' => ''
));

// Image Control
$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'about-image', array(
   'label'    => ('About Image'),
   'description' => "hi",
   'section'  => 'about-mee',
   'settings' => 'about-image',
   'priority' => 3,
)));

$wp_customize->add_section('Email_Phone', array(
  'title'          => ('Email and Num'),
  'description'    => ('change Email and Phone'),
  'panel' => 'diwp_option_panel',
  'capability' => 'edit_theme_options',
  'theme_supports' => '',
  'active_callback' => '',
  'description_hidden' => false,   
),
);
$wp_customize->add_setting( 'Email_glass_theme', array(
 
  'default' => 'erfankaharkaboody@gmail.com',
  'type'      => 'theme_mod', 

));
$wp_customize->add_setting( 'Phone_glass_theme', array(
 
  'default' => '09118472445',
  'type'    => 'theme_mod', 
 
));
$wp_customize->add_control( 'Email_glass_theme', array(
  'label'   => 'Email : ',
  'description' => 'Add Your Email',
  'section' => 'Email_Phone',
  'settings' => 'Email_glass_theme',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Add Your Email' )
)); 
$wp_customize->add_control( 'Phone_glass_theme', array(
  'label'   => 'Phone : ',
  'description' => 'Add Your Phone',
  'section' => 'Email_Phone',
  'settings' => 'Phone_glass_theme',
  'type' => 'text',
  'input_attrs' => array( 'placeholder' => 'Add Your Phone Number' )
)); 
}
add_action( 'customize_register','live_theme_customize');