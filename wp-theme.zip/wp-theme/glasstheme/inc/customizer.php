<?php 
 function customize_prof($wp_customize){
    $wp_customize->add_section('showcase', array(
        'title'          => __('Home section Edit', 'cleancut'),
        'description'    => sprintf( __('change desc and profile photo', 'cleancut')),
        'panel' => '',
        'capability' => 'edit_theme_options',
        'theme_supports' => '',
        'active_callback' => '',
        'description_hidden' => false,   
    ),
    );
    // Image Setting
    $wp_customize->add_setting('showcase_image', array(
        'default' => get_bloginfo('template_directory') . './assets/img/profile-img.png',
        'type'    => 'theme_mod'

     ));
    $wp_customize->add_setting('home_first_line', array(
        'default' => 'سلام من',
        'type'    => 'theme_mod'
     ));
    $wp_customize->add_setting('home_second_line', array(
        'default' => 'عرفان ار فرانت آکادمی',
        'type'    => 'theme_mod'
     ));
    $wp_customize->add_setting('home_tree_line', array(
        'default' => 'توسعه دهنده ی وب هستم',
        'type'    => 'theme_mod'
     ));
    $wp_customize->add_setting('home_one_button', array(
        'default' => 'بیشتر در مورد من بدانید',
        'type'    => 'theme_mod'
     ));
    $wp_customize->add_setting('home_two_button', array(
        'default' => 'نمونه کار هایم',
        'type'    => 'theme_mod'
     ));

     // Image Control
     $wp_customize->add_control('home_first_line', array(
         'label'    => 'home first text',
         'section'  => 'showcase',
         'settings' => 'home_first_line',
         'priority' => 2,
     ));
     $wp_customize->add_control('home_second_line', array(
         'label'    => 'home second text',
         'section'  => 'showcase',
         'settings' => 'home_second_line',
         'priority' => 3,
     ));
     $wp_customize->add_control('home_tree_line1', array(
         'label'    => 'home three text',
         'section'  => 'showcase',
         'settings' => 'home_tree_line',
         'priority' => 4,
     ));
     $wp_customize->add_control('home_one_button', array(
         'label'    => 'home trhree text',
         'section'  => 'showcase',
         'settings' => 'home_one_button',
         'priority' => 5,
     ));
     $wp_customize->add_control('home_two_button', array(
         'label'    => 'home trhree text',
         'section'  => 'showcase',
         'settings' => 'home_two_button',
         'priority' => 6,
     ));
     $wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'showcase_image', array(
         'label'    => __('Profile Image', 'cleancut'),
         'section'  => 'showcase',
         'settings' => 'showcase_image',
         'priority' => 1,
     )));
    

 } 
 add_action( 'customize_register','customize_prof');
 ?>