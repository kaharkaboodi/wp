<!-- Caption  -->
<section class="caption-sec sec-padding <?php 
       if (get_option('setting_field_for_glass_theme_checkbox_2') == 1) {
        echo 'hidden';
       }
      ?>">
        <h2 style="margin:30px 0; text-align:center"><?php echo esc_html(get_option('setting_field_for_glass_theme_field_1','در مورد من'))?></h2>
        <div class="text-caption">
        <?php
                          $MyCaption = new WP_Query(array(
                            'post_type' => 'about-caption',
                            'posts_per_page' => 1 ,
                          ));
                          while($MyCaption->have_posts()){
                            $MyCaption->the_post(); ?>
                             <?php the_content(); ?>
                          <?php } ?>
                          </div>
                          <?php $degrees = new WP_Query(array(
                            'post_type' => 'degrees',
                          ));
                          if($degrees->have_posts()){
                            ?>
                            <span class="caption-line"></span>
                            <h2 style="margin-top:25px; margin-bottom: 10px; text-align:center"><?php echo esc_html(get_option('setting_field_for_glass_theme_field_2','مدارک'))?></h2>
                          <?php } ?>
        <div class="degrees-caption-sec">
          <?php
                          while($degrees->have_posts()){
                            $degrees->the_post(); 
                           ?>
                            <div class="degree-items">
                              <h3><?php the_title() ?></h3>
                              <?php  $flagdegrees = get_post_meta(get_the_ID(),'post_reading_degrees',true); ?>
                              <i class="<?php echo esc_attr($flagdegrees) ?>"></i>
                             <?php the_content(); 
                             ?>
                            </div>
                            <?php } ?>
          </div>
          <?php 
            $exprince = new WP_Query(array(
              'post_type' => 'exprince',
              
            ));
            if($exprince->have_posts()){ ?>
              <span class="caption-line"></span>
              <h2 style="margin-top:25px; margin-bottom: 10px; text-align:center"><?php echo esc_html(get_option('setting_field_for_glass_theme_field_3','تجربیات همکاری'))?></h2>
           <?php } ?>
        <div class="degrees-caption-sec">
          <?php
                          while($exprince->have_posts()){
                            $exprince->the_post(); ?>
                            <div class="degree-items">  
                             <h3><?php the_title() ?></h3> 
                             <?php
                             $flag = get_post_meta(get_the_ID(),'post_reading_time',true);
                             ?>
                             <i class="<?php echo esc_attr($flag) ?>"></i>
                             <?php the_content(); ?>

                           </div>
                          <?php } ?>
                          </div>                        

           
 
        
      </section>