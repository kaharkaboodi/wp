<!-- portfolio Section Start -->
<section class="portfolio-section <?php 
       if (get_option('setting_field_for_glass_theme_checkbox_4') == 1) {
        echo 'hidden';
       }
      ?>" id="portfolio">
        <div class="container">
            <div class="row">
                <div class="section-title"><h2><?php echo esc_html(get_option('setting_field_for_glass_theme_field_5','پروژه های تکمیل شده ی اخیر'))?></h2></div>
            </div>
            <div class="row-portfolio">
            <?php 
              $Portfolios = new WP_Query(array(
              'post_type' => 'portfolios',
             ));
            while($Portfolios->have_posts()){
               $Portfolios->the_post(); ?>
            
                    <!-- portfolio item  -->
                    <div class="portfolio-item">
                    <div class="portfolio-item-thumbnail">
                      <?php the_post_thumbnail('medium'); ?>
                    </div>
                    <h3 class="portfolio-item-title"><?php the_title() ?></h3>
                    <a target="_blank" href="<?php the_permalink() ?>"><button class="btn">بازکردن پروژه</button></a>
                      <div class="portfolio-item-details">
                        <div class="description">
                            <p>
                             <?php the_excerpt(  ) ?>
                             </p>
                        </div>
                        <div class="general-info">
                            <ul>
                                <li>Creted - <span>4 Dec 2020 </span></li>
                                <li>tecnologic used - <span>Html , Css</span></li>
                                <li>Role - <span>Frontend</span></li>
                                <li>view Online - <span><a href="">www.frontacademy.ir</a></span></li>
                            </ul>
                        </div>
                      </div>
                    </div>
              
                    <?php } ?>
                  </div>
        </div>
    </section>
      
    
    <!-- portfolio  -->