<section class="contact-section sec-padding <?php 
       if (get_option('setting_field_for_glass_theme_checkbox_5') == 1) {
        echo 'hidden';
       }
      ?>" id="contact">
       <div class="container">
        <div class="row">
            <div class="section-title">
                <h2><?php echo esc_html(get_option('setting_field_for_glass_theme_field_6','ارتباط با من'))?></h2>
            </div>
        </div>
       </div>
       <div class="row">
        <div class="contact-form">
            <form action="" method="post">
                <div class="row">
                    <div class="input-group">
                        <input type="text" placeholder="نام" class="input-control" name="your_name">
                    </div>
                    <div class="input-group">
                        <input type="text" placeholder="ایمیل" class="input-control" name="your_email">
                    </div>
                    <div class="input-group">
                        <input type="text" placeholder="موضوع" class="input-control" name="your_subject">
                    </div>
                    <div class="input-group">
                        <textarea type="text" placeholder="پیام" class="input-control" name="your_message"></textarea>
                    </div>
                    <div class="submit-btn">
                        <button type="submit" class="btn" name="example_form_submit">ارسال</button>
                    </div>
                </div>
            </form>
        </div>
        <?php
          function contact_form_handler(){
            if(isset($_POST['example_form_submit'])){
                $name = sanitize_text_field($_POST['your_name'] ) ;
                $email = sanitize_text_field($_POST['your_email']);
                $Mysubject = sanitize_text_field($_POST['your_subject']);
                $Mymessage = sanitize_textarea_field($_POST['your_message']); 
                $to = 'erfankaharkaboodi@gmail.com';
                $subject = $Mysubject;
                $message =  $name .' - '. $Mymessage;
                wp_mail( $to, $subject, $message);  
            }
          }
          add_action('wp_head','contact_form_handler');
        
        ?>
        <div class="contact-info">
            <div class="contact-info-item">
                <h3>پست الکترونیکی</h3>
                <p><?php echo esc_html(get_theme_mod('Email_glass_theme')) ?></p>
            </div>
            <div class="contact-info-item">
                <h3>تلفن</h3>
                <p><?php echo esc_html(get_theme_mod('Phone_glass_theme')) ?></p>
            </div>
            <div class="contact-info-item">
                <h3>شبکه های اجتماعی</h3>
                <div class="social-links">
                    <a href="#" target="_blank">
                        <i class="fa-brands fa-github"></i></a>
                    <a href="<?php echo esc_url(get_theme_mod( 'icon2_address','www.facebook.com'))?>" target="_blank"><i class="<?php echo esc_attr(get_theme_mod( 'icon2','fa-brands fa-facebook-f'))?>"></i></a>
                    <a href="<?php echo esc_url(get_theme_mod( 'icon3_address','www.facebook.com'))?>" target="_blank"><i class="<?php echo esc_attr(get_theme_mod( 'icon3','fa-brands fa-facebook-f'))?>"></i></a>
                    <a href="<?php echo esc_url(get_theme_mod( 'icon4_address','www.facebook.com'))?>" target="_blank"><i class="<?php echo esc_attr(get_theme_mod( 'icon4','fa-brands fa-facebook-f'))?>"></i></a>
                    <a href="<?php echo esc_url(get_theme_mod( 'icon5_address','www.facebook.com'))?>" target="_blank"><i class="<?php echo esc_attr(get_theme_mod( 'icon5','fa-brands fa-facebook-f'))?>"></i></a>
                    <a href="<?php echo esc_url(get_theme_mod( 'icon1_address','www.facebook.com'))?>" target="_blank"><i class="<?php echo esc_attr(get_theme_mod( 'diwp_site_title','fa-brands fa-facebook-f'))?>"></i></a>
                </div>
            </div>
        </div>
       </div>
    </section>