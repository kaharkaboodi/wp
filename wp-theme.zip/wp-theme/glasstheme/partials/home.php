<div class="main">

      <!-- Home section Start -->
      <section class="home-section align-items-center <?php 
       if (get_option('setting_field_for_glass_theme_checkbox_1') == 1) {
        echo 'hidden';
       }
      ?>">
        <div class="container">
            <div class="row align-items-center">
                <div class="home-text">
                    <p><?php echo esc_html(get_theme_mod('home_first_line')) ?></p>
                    <h1><?php echo esc_html(get_theme_mod('home_second_line')) ?></h1>
                    <h2><?php echo esc_html(get_theme_mod('home_tree_line'))?></h2>
                    <a href="#" class="btn"><?php echo esc_html(get_theme_mod('home_one_button')) ?></a>
                    <a href="#" class="btn"><?php echo esc_html(get_theme_mod('home_two_button')) ?></a>
                </div>
                <div class="home-img">
                    <div class="img-box">
                        <img src="<?php echo esc_url(get_theme_mod('showcase_image', get_bloginfo('template_url').'./assets/img/profile-img.png')) ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
      </section>
      

    