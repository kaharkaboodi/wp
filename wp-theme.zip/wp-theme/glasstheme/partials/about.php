<section class="about-section sec-padding <?php 
       if (get_option('setting_field_for_glass_theme_checkbox_3') == 1) {
        echo 'hidden';
       }
      ?>" id="about" style="direction:ltr">
        <div class="container">
            <div class="row">
                <div class="section-title">
                    <h2><?php echo esc_html(get_option('setting_field_for_glass_theme_field_4','بخشی از مهارت هام'))?></h2>
                </div>
            </div>
            <div class="row">
                <div class="about-img">
                <div class="img-box">
                    <img src="<?php echo esc_url(get_theme_mod('about-image',  get_bloginfo('template_url').'./assets/img/about-img.png')) ?>">
                </div>
                </div>
           
                <div class="about-text">
                    <h3>skils</h3>
                    <div class="skills">
                          <?php 
                           $Tags = new WP_Query(array(
                            'post_type' => 'tags-ability'
                          ));
                          while($Tags->have_posts()){
                            $Tags->the_post(); ?>
                            <div class="skill-item"><?php the_title(); ?></div>
                          <?php } ?>
                    </div>
                    <h3 class="about-heading">my ability</h3>
                    <div class="skills-progress">
                       <?php
                          $Myskillbars = new WP_Query(array(
                            'post_type' => 'skillbars',
                            'p' => 143,
                            'posts_per_page' => 1 ,
                          ));
                          while($Myskillbars->have_posts()){
                            $Myskillbars->the_post(); ?>
                             <?php the_content(); ?>
                          <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>