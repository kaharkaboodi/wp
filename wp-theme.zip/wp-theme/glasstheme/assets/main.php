<?php 
require_once('../../../../wp-config.php');
header("Content-type: text/css");
// include_once('wp-includes\option.php');
 ?>

/*  Variable */
:root{
    --main-color : #e02f6b;
    --blue:#0000ff;
    --blue-dark:#18293c;
    --orange:#ffa500;
    --green-yellow:#cddc39;
    --pink-light: #efa2b4;
    --cyan-light:#aef1ee;
    --cyan-dark:#337f92;
    --white: #ffffff;
    --white-alpha-40:rgba(255,255,255,0.40);
    --white-alpha-25:rgba(255,255,255,0.25);
    --white-alpha-10:rgba(255,255,255,0.45);
    --backdrop-filter-blur: blur(50px) 
 }
 
 *{
     box-sizing: border-box;
     padding: 0;
     margin: 0;
     outline: none;
     scroll-behavior: smooth;
 }
 ::before,::after{
     box-sizing: border-box ;
 } 
 h1,h2{
     font-weight: 600;
 }
 h3,h4,h5,h6{
     font-weight: 500;
 }
 a{
     text-decoration: none;
 }
 body{
     min-height: 100vh;
     background-image: linear-gradient(to bottom right, var(--pink-light),var(--cyan-dark));
     font-size: 16px;
     line-height: 1.5rem;
     padding: 5vh 15px;
 }
 body::before{
     content: '';
     position: fixed;
     left: 0;
     top: 0;
     height: 100%;
     width: 100%;
     background-color: var(--green-yellow);
     z-index: -1;
     opacity: 0.12;
 }
 ::-webkit-scrollbar{
     width: 5px;
 }
 ::-webkit-scrollbar-track{
   background-color: var(--white);
 }
 ::-webkit-scrollbar-thumb{
     background-color: var(--main-color);
 }
 img{
     max-width: 100%;
     vertical-align: middle;
 }
 section{
     background-color: var(--white-alpha-25);
     border:1px solid var(--white-alpha-40);
     min-height: 90vh;
     border-radius: 30px;
     backdrop-filter: var(--backdrop-filter-blur);
     margin:10px 0
 }
 .main{
     max-width: 1200px;
     margin: auto; 
     position: relative;
 }
 .container{
    padding: 0 40px;
    width: 100%;
 } 
 .row{
     display: flex;
     flex-wrap: wrap;
 }
 .align-items-center{
     align-items: center;
 }
 /* buttons */
 .btn{
     line-height: 1.5;
     background-color: var(--white-alpha-25);
     padding: 10px 20px;
     display: inline-block;
     border: 1px var(--white-alpha-50);
     border-radius: 30px;
     color: var(--main-color);
     font-weight: 500;
     text-transform: capitalize;
     font-family: inherit;
     font-size: 16px;
     cursor: pointer;
     user-select: none;
     position: relative;
     overflow: hidden;
     vertical-align: middle;
     transition: color 0.3s ease;
 }
 .btn::before{
     content: '';
     position: absolute;
     left: 0;
     top: 0;
     height: 100%;
     width: 0%;
     background-color: var(--main-color);
     z-index: -1;
     transition: width 0.3s ease;
 }
 .btn:hover::before{
     width: 100%;
 }
 .btn:hover{
     color: var(--white);
 }
 /* Header */
 .header{
     position: absolute;
     left: 0;
     top: 0;
     width: 100%;
     z-index: 1;
     padding: 20px 0 0 ;
 }
 .header .nav-toggler{
     width: 50px;
     height: 50px;
     border: none;
     cursor: pointer;
     border-radius: 50%;
     background-color: var(--white-alpha-25);
     border: 1px solid var(--white-alpha-40);
     display: flex;
     align-items: center;
     position: fixed;
     z-index: 5555;
     justify-content: center;
     margin: 0 15px;
 }
 .header .nav-toggler span{
     height: 2px;
     width: 24px;
     background-color: var(--main-color);
     position: relative;
 }
 .header .nav-toggler span:after,.header .nav-toggler span::before{
     content: '';
     position: absolute;
     top: 0;
     width: 100%;
     height: 100%;
     background-color: var(--main-color);
     transition: all 0.3s ease;
 }
 .header .nav-toggler:hover span::before,
 .header .nav-toggler:hover span::after{
    width: 50%;
 
 }
 .header .nav-toggler span::before{
     left: 0;
     transform: translateY(-8px);
 }
 .header .nav-toggler span::after{
     right: 0;
     transform: translateY(8px);
 }
 .flex-end{
     justify-content: flex-end ;
 }
 .nav{
     display: none;
 }
 /* end HeADER */
 .close span:first-child{
     transform:translate(10px) rotate(45deg);
 }
 .close span:last-child{
     transform: translate(-5px) rotate(-45deg);
 }
 .header #nav{
     position: fixed;
     left: 0;
     top: 0;
     height: 100%;
     width: 100%;
     padding: 35px 15px;
     /* visibility: hidden; */
 }
 .header .nav-inner{
    min-height: calc(100vh - 70px);
    max-width: 1200px;
    margin: auto;
    background-color: var(--white-alpha-25);
    border: 1px solid var(--white-alpha-40);
    backdrop-filter: var(--backdrop-filter-blur);
    padding: 50px 0;
    border-radius: 30px;
    display: flex;
    justify-content: center;
 }
 .header  .nav-inner ul{
   width: 30%;
 }
 .header  .nav-inner ul li{
     list-style: none;
     margin: 20px 0;
     background-color: var(--white-alpha-40);
     min-height: 20px;
     min-width: 150px;
     padding: 2px;
     display: flex;
     justify-content: center;
     transition: all 0.75s ease;
 }
 .header  .nav-inner ul li:hover{
     background-color: var(--main-color);
 }
 .header .nav-inner ul li:hover a{
     color: white;
 }
 .header .nav-inner ul li a{
     font-size: 22px;
     color:  var(--main-color);
     padding: 20px 40px;
 }
 
 /* Home Section  */ 
 .home-text,.home-img{
     width: 50%;
     padding: 15px;
 }
 .home-text h2{
     font-size: 20px;
     text-transform: capitalize;
     font-weight: 300;
     margin: 0 0 30px;
 }
 .home-text .btn{
     margin: 0 15px 15px 0;
 }
 .home-section{
    display: flex;
    padding: 120px 0;
 }
 .home-img .img-box{
     max-width: 360px;
     background-color: var(--white-alpha-25);
     border-radius: 50%;
     border: 8px solid var(--white-alpha-25);
     margin: auto;
 }
 .home-img .img-box img{
     width: 100%;
     border-radius: 50%;
 }
 .hidden{
     display: none;
 }
 /* Section Title  */
 .sep-padding{
     padding: 80px 0px;
 }
 .section-title{
     padding: 0 15px;
     margin-top: 40px;
     margin-bottom: 40px;
     width: 100%;
     text-align: center;
 }
 .section-title h2{
     font-size: 40px;
     text-transform: capitalize;
 }
 /* About Section  */
 about-section{
    display:flex;
    justify-content:space-between;
 }
 .about-text{
     width: 58%;
     padding: 0 15px; 
     font-size: 18px;
 }
 .about-img .img-box{
     background-color: var(--white-alpha-25);
     max-width: 380px;
     border: 1px solid var(--white-alpha-40);
     margin: auto;
     border-radius: 10px;
     margin-bottom: 1rem;
 }
 .about-img .img-box img{
     width: 100%;
 }
 .about-text h3{
       text-transform: capitalize;
       font-size: 20px;
       margin: 0 0 20px 0;
       font-size: 22px;
 
 font-weight: bold;    }
 .about-text .skills{
     display: flex;
     flex-wrap: wrap;
 }
 .about-text .skill-item{
     background-color: var(--white-alpha-25);
     border: 1px solid var(--white-alpha-40);
     padding: 5px 15px;
     text-transform: capitalize;
     margin: 0 10px 10px 0;
     border-radius: 20px;
 }
 .about-heading{
     font-weight: bold;
     font-size: 22px !important;
     margin: 10px 0 !important;
 }
 .skills-progress .progressbar{
     padding:0.025rem 1.5rem;
     margin: 1rem 0;
     background-color: var(--white-alpha-10);
     border-radius: 1rem;
 }
 .skills-progress .progressbar h3{
     display: flex;
     justify-content: space-between;
     font-size: 1rem;
     color: #080808;
     margin-bottom: 0.5rem;
     margin-top: 0.5rem;
 }
 .skills-progress .progressbar .bar{
     position: relative;
     width: 100%;
     height: 0.3rem;
     margin: 0 0 0.75rem 0;
     background-color: rgba(167, 161, 161, 0.466);
 }
 .skills-progress .progressbar .bar span{
     position: absolute;
     background-color: rgb(122, 2, 2);
     top: 0;left: 0;
     height: 100%;
     width: 100%;
 }
 .skills-progress .progressbar:nth-child(1) .bar span{
     width: 50%;
 }
 /* Portfolio */
 .row-portfolio{
     display: flex;
     flex-direction: row;
     flex-wrap: wrap;
     justify-content: center;
     align-items: center;
 }
 .portfolio-item{
     width: calc((100% / 3) - 30px);
     margin: 0 15px 30px;
 }
 .portfolio-item-thumbnail{
     background-color: var(--white-alpha-25);
     padding: 10px
 }
 .portfolio-item-thumbnail img{
     width: 100%;
     object-fit: cover;
 }
 .portfolio-item-details{
     display: none;
 }
 /* Contact form  */
 .contact-form,.contact-info{
     width: 50%;
     padding: 0 15px;
 }
 
 .contact-form .input-group{
     width: 100%;
     margin-bottom: 30px;
 }
 .contact-form .input-control::placeholder{
     color: var(--blue-dark);
     opacity: 0.8;
     font-weight: 300;
 }
 .contact-form .input-control{
     display: block;
     width: 100%;
     height: 50px;
     border-radius: 25px;
     border: none;
     font-family: inherit;
     font-weight: 400;
     font-size: 16px;
     background-color: var(--white-alpha-25);
     padding: 0 20px;
     color: var(--blue);
     border: 1px solid transparent;
     transition: border-color 0.3s ease;
 }
 .contact-form .input-control:focus{
     border-color: var(--white-alpha-40);
 }
 .contact-form textarea.input-control{
     resize: none;
     height: 100px;
     padding-top: 15px;
 }
 .contact-info-item{
     margin: 0 0 30px;
     padding: 0 0 0 20px;
 }
 .contact-info-item h3{
     font-size: 20px;
     text-transform: capitalize;
     margin: 0 0 5px;
 }
 .contact-info-item .social-links a{
     display: inline-flex;
     height: 40px;
     width: 40px;
     margin: 10px 0;
     justify-content: center;
     align-items: center;
     background-color: var(--white-alpha-25);
     border: 1px solid var(--white-alpha-40);
     color: var(--main-color);
     transition: all 0.3s ease;
 }
 .contact-info-item .social-links a:hover{
     background-color: var(--main-color);
     color: white;
 }
 .caption-line{
    height: 2px;
    width: 100%;
    background-color: var(--main-color);
    display: block;
}
.degrees-caption-sec{
    padding: 20px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}
.text-caption p{
    padding: 10px;
}
.degree-items{
    margin: 10px 0;
    width:calc((100% / 3) - 30px);
    background-color: var(--white-alpha-10);
    display: grid;
    grid-template-columns:auto auto auto;
    box-shadow: 1px 1px 7px 1px var(--pink-light);
    height:auto;

}
.degree-items  p{
    grid-column: 1 / span 2;
    padding: 10px;
    font-weight: bold;
    line-break:anywhere
}
.degree-items h3{
    font-size: 2em;
    padding: 10px;
}
.degree-items i{
    padding-top: 22px;
}
h2{
  color:<?= get_option( 'setting_section_for_glass_theme');?> ;
}