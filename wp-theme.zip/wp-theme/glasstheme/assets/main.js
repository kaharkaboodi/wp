const togglebuttonformenu = document.querySelector('#nav-toggler');
const headerContainer = document.querySelector('#nav')
togglebuttonformenu.addEventListener('click', ()=>{
    headerContainer.classList.toggle('nav')
})