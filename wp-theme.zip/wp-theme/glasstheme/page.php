<?php
 get_header();
 ?><section class="home-section align-items-center">
 <div class="container">
         <?php the_content(); ?>
         

 </div>
</section>

  <?php
 get_footer();
?>