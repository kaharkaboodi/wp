<?php  get_header() ?>
<?php get_template_part('partials/home') ?>
<?php get_template_part('partials/caption') ?>
<?php get_template_part('partials/about') ?>
<?php get_template_part('partials/portfolio') ?>
<?php get_template_part('partials/contact') ?>
<?php get_footer() ?>