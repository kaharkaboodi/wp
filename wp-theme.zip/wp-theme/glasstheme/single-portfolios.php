<?php 
get_header('page');
?>
 <div class="portfolio-item-blog">
                    <div class="portfolio-item-thumbnail-single">
                      <?php the_post_thumbnail('medium'); ?>
                    </div>
                    <h2 class="portfolio-title"><?php the_title() ?></h2>
                  
                      <div class="portfolio-item-details-single">
                        <div class="description">
                            
                             <?php the_content() ?>
                            
                        </div>
                      </div>
                    </div>
</div>
<?php

get_footer();
?>