<?php 
/*
 function progressbar_admin_page(){

    add_menu_page('skillbar', 'Edit Skillbars','manage_options', 'skillbars', "wrapper_settings_skillbar", "dashicons-edit-large", 5 );
 }
function wrapper_settings_skillbar(){
   ?>
     <h2>hi</h2>
     <form action="options.php" method="POST">
        <?php
        settings_fields('myskillbars');
         do_settings_sections('skillbars') ;
              submit_button( ); 
        ?>
     </form>
   <?php
}
add_action('admin_menu','progressbar_admin_page');
add_action('admin_init','skillbar_init' );
function skillbar_init(){
   add_settings_section('skillbar_sec',null,null,'skillbars');
   add_settings_field('skillbar_id','width','skillbar_field','skillbars','skillbar_sec');
   register_setting('myskillbars','skillbar_id',array(
      'sanatize_callback' => 'sanatize_text_field', 'default' => 'def'
   ));
}

function skillbar_field(){
   ?>
    <input type="text" id="skillbar_id" name="skillbar_id" value="<?php echo get_option('skillbar_id' ); ?>" >
   <?php
}


*/
?>