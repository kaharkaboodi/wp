<?php 
function my_admin_setting_page_for_glasss_theme(){
	add_menu_page('setting page',__('تنظیمات سفارشی','glasstheme'),'manage_options', 'customize-setting-page','my_admin_setting_page_content_for_glasss_theme', 'dashicons-admin-generic', 31);	
    // add_settings_section('setting_page_section','setting page','my_setting_section_callback','customize-setting-page')
}
function my_admin_setting_page_content_for_glasss_theme(){
	?>
	<h1>
      <?php esc_html_e( 'به صفحه ی تنظیمات قالب خوش آمدید', 'glasstheme') ?>		
	</h1>
	<form method="POST" action="options.php">
    <?php
    settings_fields('customize-setting-page');
    do_settings_sections('customize-setting-page');
    submit_button();
    ?>
    </form>
    <?php
 } 
add_action('admin_menu','my_admin_setting_page_for_glasss_theme');
add_action('admin_init','my_setting_init_for_glass_theme');
function my_setting_init_for_glass_theme(){
	add_settings_section('setting_field_for_glass_theme_field','تنظیمات کلی','setting_field_for_glass_theme_field__front','customize-setting-page');
	add_settings_field( 'setting_field_for_glass_theme_field_1',__('تیتر اول','glasstheme'),'callback_function_for_glass_theme','customize-setting-page','setting_field_for_glass_theme_field',array('theNameField' => 'setting_field_for_glass_theme_field_1'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_field_1',array('sanitize_callback' => 'sanitize_text_field','default'=>'در مورد من'));
	add_settings_field( 'setting_field_for_glass_theme_field_2',__('تیتر دوم','glasstheme'),'callback_function_for_glass_theme','customize-setting-page','setting_field_for_glass_theme_field',array('theNameField' => 'setting_field_for_glass_theme_field_2'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_field_2',array('sanitize_callback' => 'sanitize_text_field','default'=>'مدرک'));
	add_settings_field( 'setting_field_for_glass_theme_field_3',__('تیتر سوم','glasstheme'),'callback_function_for_glass_theme','customize-setting-page','setting_field_for_glass_theme_field',array('theNameField' => 'setting_field_for_glass_theme_field_3'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_field_3',array('sanitize_callback' => 'sanitize_text_field','default'=>'همکاری ها'));
	add_settings_field( 'setting_field_for_glass_theme_field_4',__('تیتر چهارم','glasstheme'),'callback_function_for_glass_theme','customize-setting-page','setting_field_for_glass_theme_field',array('theNameField' => 'setting_field_for_glass_theme_field_4'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_field_4',array('sanitize_callback' => 'sanitize_text_field','default'=>'بخشی از توانایی هام'));
	add_settings_field( 'setting_field_for_glass_theme_field_5',__('تیتر پنجم','glasstheme'),'callback_function_for_glass_theme','customize-setting-page','setting_field_for_glass_theme_field',array('theNameField' => 'setting_field_for_glass_theme_field_5'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_field_5',array('sanitize_callback' => 'sanitize_text_field','default'=>'کار های اخیر'));
	add_settings_field( 'setting_field_for_glass_theme_field_6',__('تیتر ششم','glasstheme'),'callback_function_for_glass_theme','customize-setting-page','setting_field_for_glass_theme_field',array('theNameField' => 'setting_field_for_glass_theme_field_6'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_field_6',array('sanitize_callback' => 'sanitize_text_field','default'=>'ارتباط با من'));

    add_settings_field('setting_field_for_glass_theme_checkbox_1',__('فعال/غیرفعال کردن قسمت اول','glasstheme'), 'callback_function_for_glass_theme_checkbox_1','customize-setting-page','setting_field_for_glass_theme_field',array('theName' => 'setting_field_for_glass_theme_checkbox_1'));
    register_setting( 'customize-setting-page','setting_field_for_glass_theme_checkbox_1',array('sanitize_callback' => 'sanitize_text_field','default'=>'0'));
   
    add_settings_field('setting_field_for_glass_theme_checkbox_2',__('فعال/غیرفعال کردن قسمت دوم','glasstheme'), 'callback_function_for_glass_theme_checkbox_1','customize-setting-page','setting_field_for_glass_theme_field',array('theName' => 'setting_field_for_glass_theme_checkbox_2'));
    register_setting( 'customize-setting-page','setting_field_for_glass_theme_checkbox_2',array('sanitize_callback' => 'sanitize_text_field','default'=>'0'));
   
    add_settings_field('setting_field_for_glass_theme_checkbox_3',__('فعال/غیرفعال کردن قسمت سوم','glasstheme'), 'callback_function_for_glass_theme_checkbox_1','customize-setting-page','setting_field_for_glass_theme_field',array('theName' => 'setting_field_for_glass_theme_checkbox_3'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_checkbox_3',array('sanitize_callback' => 'sanitize_text_field','default'=>'0'));
   
    add_settings_field('setting_field_for_glass_theme_checkbox_4',__('فعال/غیرفعال کردن قسمت چهارم','glasstheme'), 'callback_function_for_glass_theme_checkbox_1','customize-setting-page','setting_field_for_glass_theme_field',array('theName' => 'setting_field_for_glass_theme_checkbox_4'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_checkbox_4',array('sanitize_callback' => 'sanitize_text_field','default'=>'0'));
   
    add_settings_field('setting_field_for_glass_theme_checkbox_5',__('فعال/غیرفعال کردن قسمت پنجم','glasstheme'), 'callback_function_for_glass_theme_checkbox_1','customize-setting-page','setting_field_for_glass_theme_field',array('theName' => 'setting_field_for_glass_theme_checkbox_5'));
    register_setting( 'customize-setting-page', 'setting_field_for_glass_theme_checkbox_5',array('sanitize_callback' => 'sanitize_text_field','default'=>'0'));

}
function setting_field_for_glass_theme_field__front(){
    echo '<h3>سلام ! ازین قسمت هر کدام از پنج قسمت صفحه ی اصلی را می توانید پنهان و ننظیم کنید</h3>';
}
function callback_function_for_glass_theme_checkbox_1($args){
    ?>
    <input type="checkbox" name="<?php echo $args['theName'] ?>" value="1" <?php checked(get_option($args['theName']),'1'); ?> >
<?php } 
/*<?php _e( 'ورودی یک','glasstheme' ); ?>*/
function callback_function_for_glass_theme($args){
   ?>
    <!-- <label for="my_setting_field">/label> -->
    <input type="text" id="my_setting_field" name="<?php echo $args['theNameField'] ?>" value="<?php echo esc_attr(get_option($args['theNameField']),'hi'); ?>">
   <?php
}
?>


