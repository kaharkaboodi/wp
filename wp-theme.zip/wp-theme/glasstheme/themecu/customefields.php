<?php
// custom Dashbord Widget
/*
add_action('wp_dashboard_setup','custom_dashboard_widget_contact_details');
function custom_dashboard_widget_contact_details() {
  if(current_user_can( 'manage_options')){
    wp_add_dashboard_widget( 'custom_contact_widget','Contact Details','custom_dashboard_contact');
  }
}
// Display Form
if(!function_exists('custom_dashboard_contact')){ 
 function custom_dashboard_contact(){
   ?>
    <div class="wrap">
        <form action="options.php" method="post">
          <?php wp_nonce_field( 'update-options'); ?>
          <table>
            <tr>
                <th scope="row" width="120" align="left" valign="top">Phone Number:</th>
                <td>
                    <input type="number" name="phone_number" size="255" value='<?php echo get_option('phone_number') ?>'>
                </td>
            </tr>

            <tr>
                <th scope="row" width="120" align="left" valign="top">Email Address:</th>
                <td>
                    <input type="text" name="email_address" size="255" value='<?php echo get_option('email_address') ?>' style="width:98%">
                </td>
            </tr>
            
          </table>
          <input type="hidden" name="action" value="update" />
          <input type="hidden" name="page_options" value="phone_number, email_address" />
          <p class="submit">
            <input type="submit" class="btn btn-primarry" value="<?php _e('Save changed') ?>">
          </p>
        </form>
    </div>

   <?php   
 }
}

*/

?>