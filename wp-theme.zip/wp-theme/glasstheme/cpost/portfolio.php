<?php

function custome_portfolio_post_for_glass_theme(){
   register_post_type('portfolios', array(
     'public' => true,
     'rewrite' => array('slug' => 'portfolios'),
     'has_archive' => true,
     'supports' =>array('themes','title','editor','author','thumbnail','expert') ,
     'labels' => array(
       'name' => 'portfolio posts',
       'add_new_item' => 'add portfolio',
       'edit_item' => 'edit portfolio',
       'all_items' => 'All portfolios',
      //  'capability_type' => 'portfolios',
      ),
     'singular_name' => 'Portfolios',
     'show_in_rest' => true,
     'menu_icon' => 'dashicons-screenoptions',
   ));
}
add_action('init','custome_portfolio_post_for_glass_theme');

?>