<?php

function custome_exprience_post_for_glass_theme(){
   register_post_type('exprince', array(
     'public' => true,
     'rewrite' => array('slug' => 'exprince'),
     'has_archive' => true,
     'supports' =>array('themes','title','editor','author','thumbnail','expert') ,
     'labels' => array(
       'name' => 'exprience',
       'add_new_item' => 'add exprience',
       'edit_item' => 'edit exprience',
       'all_items' => 'All exprince',
      //  'capability_type' => 'exprince',
      ),
     'singular_name' => 'exprince',
     'show_in_rest' => true,
     'menu_icon' => 'dashicons-businessman',
   ));
  }
  add_action('init','custome_exprience_post_for_glass_theme');

function custom_field_glass_theme(){
  add_meta_box('carsglass','Cars Details','CF','exprince','normal','low');
}
add_action('add_meta_boxes','custom_field_glass_theme');
function CF(){
  global $post;
  ?>
  <style>
    p{
      font-size:20px;
    }
    </style>
    <p>استفاده میکنیم برای مثال fontawsom ما از کلاس های </p>
    <code>&lt;i class="fa-solid fa-school-flag fa-2xl"&gt;&lt;i&gt;</code>
    <p>کد بالا نشان دهنده ی ایکون پایینی هست</p>
    <i class="fa-solid fa-school-flag fa-2xl"></i>
    <p>برای نمایش آیکون های متفاوت کافیست کلاس مخصوص آنرا بنویسید همانند مقدار پیش فرض در فیلد
    </p>
    <input type="text" name="input_custom_field" value="<?php echo esc_attr(get_post_meta($post->ID,'post_reading_time', true)) ?>" />
    <?php
}
function save_custom_field(){
  global $post;
  if(isset($_POST["input_custom_field"])) :
    $input_custom_field = sanitize_text_field($_POST["input_custom_field"]);
    update_post_meta($post->ID,'post_reading_time',$input_custom_field);
  endif;
}
add_action('save_post','save_custom_field');
?>