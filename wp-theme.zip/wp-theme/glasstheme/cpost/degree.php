<?php

function custome_degree_post_for_glass_theme(){
   register_post_type('degrees', array(
     'public' => true,
     'rewrite' => array('slug' => 'degrees'),
     'has_archive' => true,
    //  'supports' =>array('themes','title','editor') ,
     'labels' => array(
       'name' => 'degree',
       'add_new_item' => 'add degree',
       'edit_item' => 'edit degree',
       'all_items' => 'All degrees',
      //  'capability_type' => 'degrees',
      ),
     'singular_name' => 'degrees',
     'show_in_rest' => true,
     'menu_icon' => 'dashicons-book',
  ));
}
add_action('init','custome_degree_post_for_glass_theme');
function custom_field_glass_theme_degrees(){
  add_meta_box('degreeforglasstheme','کلاس آیکون','caption_degree','degrees','normal','low');
}
add_action('add_meta_boxes','custom_field_glass_theme_degrees');
function caption_degree(){
  global $post;
  ?>
  <style>
   
    </style>
    <p>استفاده میکنیم برای مثال fontawsom ما از کلاس های </p>
    <code><i class="fa-solid fa-school-flag fa-2xl"></i></code>
    <p>کد بالا نشان دهنده ی ایکون پایینی هست</p>
    <code>&lt;i class="fa-solid fa-school-flag fa-2xl"&gt;&lt;i&gt;</code>
    <p>برای نمایش آیکون های متفاوت کافیست کلاس مخصوص آنرا بنویسید همانند مقدار پیش فرض در فیلد پایین
    </p>
    <input type="text" name="input_custom_field_degrees" value="<?php echo esc_attr(get_post_meta($post->ID,'post_reading_degrees', true)) ?>" />
    <?php
}
function save_custom_field_degrees(){
  global $post;
  if(isset($_POST["input_custom_field_degrees"])) :
    $input_custom_field_degrees = sanitize_text_field($_POST["input_custom_field_degrees"]);
    update_post_meta($post->ID,'post_reading_degrees',$input_custom_field_degrees);
  endif;
}
add_action('save_post','save_custom_field_degrees');
?>