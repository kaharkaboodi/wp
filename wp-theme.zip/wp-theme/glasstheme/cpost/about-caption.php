<?php
function custome_about_caption_post_for_glass_theme(){
   register_post_type('about-caption', array(
     'public' => true,
     'rewrite' => array('slug' => 'about-caption'),
     'has_archive' => true,
     'supports' =>array('title','editor','thumbnail') ,
     'labels' => array(
       'name' => 'about caption',
       'add_new_item' => 'add about caption',
       'edit_item' => 'edit about caption',
       'all_items' => 'All about captions',
     ),
     'capabilities' => array(
      'create_posts' => false,
    ),
    'map_meta_cap' => true,
     'show_in_rest' => true,
     'menu_icon' => 'dashicons-format-aside',
   ));
}
add_action('init','custome_about_caption_post_for_glass_theme');
?>