<?php
 function tag_post_type(){
    register_post_type('tags-ability', array(
      'public' => true,
      'supports' => array('title'),
      'labels' => array(
        'name' => 'tags ability',
        'add_new_item' => 'add new tag',
        'edit_item' => 'edit tag',
        'all_items' => 'All Tags',
      ),
      'menu_icon' => 'dashicons-tag',
    ));
 }
 add_action('init','tag_post_type');