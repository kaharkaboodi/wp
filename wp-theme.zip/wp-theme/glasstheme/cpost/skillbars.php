<?php

function skillbar_for_glass_theme(){
   register_post_type('skillbars', array(
     'public' => true,
     'labels' => array(
       'name' => 'Skillbar group',
       'add_new_item' => 'add new prgressbar grop',
       'edit_item' => 'edit progressbar',
       'all_items' => 'All skillbars',
     ),
     'capabilities' => array(
      'create_posts' => false,
    ),
    'map_meta_cap' => true,
     'menu_icon' => 'dashicons-art',
   ));
}
add_action('init','skillbar_for_glass_theme');

?>