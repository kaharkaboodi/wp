<?php

function contact_form_for_glass_theme(){
  $contact_content = ' <form action="">
                            <div class="row">
                                <div class="input-group">
                                    <input type="text" placeholder="Name" 
                                    name="your_name"
                                    class="input-control">
                                </div>
                                <div class="input-group">
                                    <input type="text" placeholder="Email" name="your_email"
                                    class="input-control">
                                </div>
                                <div class="input-group">
                                    <input type="text" name="your_subject" placeholder="Subject" class="input-control">
                                </div>
                                <div class="input-group">
                                    <textarea type="text" placeholder="Message" name="your_message" class="input-control"></textarea>
                                </div>
                                <div class="submit-btn">
                                    <button type="submit" class="btn">send message</button>
                                </div>
                            </div>
                        </form>';
  return $contact_content

}
add_shortcode('contact_form_for_glasstheme', 'contact_form_for_glass_theme');
function contact_form_for_glass_theme(){
    if(isset($_POST['example_form_submit'])){
        $name = sanitize_text_field($_POST['your_name'] ) ;
        $email = sanitize_email($_POST['your_email']);
        $Mysubject = sanitize_text($_POST['your_subject']);
        $Mymessage = sanitize_textarea_field($_POST['your_message']); 
        $to = 'erfankaharkaboodi@gmail.com';
        $subject = $Mymessage;
        $message = $Mymessage;
        wp_mail( $to, $subject, $message);  
    }
}

?>