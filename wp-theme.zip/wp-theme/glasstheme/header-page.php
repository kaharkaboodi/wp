<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <?php wp_head();
        //  echo get_option('phone_number');
        //  echo get_option('email_address');
         
         ?>
        
</head>
<body>
   <!-- Header start -->
   <header class="header">
                <div class="container">
                    <div class="row flex-end">
                        
                       <button  onclick="window.location.href ='<?php echo home_url(); ?>'" class="nav-toggler" id="nav-toggler">
                            <i class="fa-solid fa-house" style="color:#e02f6b"></i>
                        </button>
                    </div>
                </div>
             </header>     
