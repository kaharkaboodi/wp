<?php 
function my_theme_setup(){
    register_nav_menu('primary' , __('Primary Menu' , 'theme-slug'));
    add_theme_support('custome-logo');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails', ['post','page','portfolios']);
    add_theme_support('portfolios','thumbnail');
    add_theme_support('automatic-feed-links');
    add_image_size( 'blogimg',400 , 640, array('center' , 'center') );
  }
  add_action( 'after_setup_theme', 'my_theme_setup' );
function styles_scripts(){
  global $wp_styles;
    wp_enqueue_style( 'main-style', get_stylesheet_uri(),[],time(),false,'all');
    wp_enqueue_script('main-js',get_template_directory_uri() . './assets/main.js', [],'1.0.0', true );
    if (post_type_exists('portfolios')) {
      wp_enqueue_style('main-js',get_template_directory_uri() . './assets/portfolio.css');
    }
};
add_action('wp_enqueue_scripts','styles_scripts');
// add_post_meta(10123,'degree','master',true);

get_template_part( 'inc/customizer');
get_template_part( 'inc/customizepanel');
get_template_part( 'cpost/tags');
get_template_part( 'cpost/portfolio');
get_template_part( 'cpost/degree');
get_template_part( 'cpost/expreince');
get_template_part( 'cpost/about-caption');
get_template_part( 'cpost/skillbars');
get_template_part( 'cpostt/contactform');
get_template_part( 'themecu/settings');
get_template_part( 'themecu/progressbar');
get_template_part( 'themecu/customefields');

?>