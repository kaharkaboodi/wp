<?php
 /*
Plugin Name: Glass Skillbar
Plugin URI: https://github.com/zgordon/wp-dev-course
Description: a plugin that give you shortcodes for you
Version: 1.0.0
Contributors: zgordon
Author: Erfan kahar
Author URI: https://zacgordon.com
License: GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: wpplugin 
Domain Path:  /languages
*/


class GlassSkillbarForGlassTheme{
    function __construct(){
        add_action('admin_menu',array($this,'adminPage'));
        // add_action('wp_print_styles', array($this,'skillbar_register_styles'));
        add_action('wp_enqueue_scripts',array($this,'skillbar_register_styles'));
        add_shortcode('skillbar',array($this,'myshortcode'));
    }
    function skillbar_register_styles() {
        $dirpath = plugin_dir_url(__FILE__);
        wp_enqueue_style('st' , $dirpath . './barr.css');
      }
    function adminPage(){
        add_menu_page( 'Skillbar Edit','Skillbar','manage_options','customize-skillbar-for-glass-theme',array($this,'ourHTML'), 'dashicons-wordpress-alt', 100 );
        add_options_page( 'Skillbar Edit','Skillbar','manage_options','customize-skillbar-for-glass-theme',array($this,'ourHTML'));    
    }
    function ourHTML(){ ?>
        <div class="wrap">
            <h2>اینجوری انجام بده </h2>
            <code>[skillbar grow="95%" title="html" /]</code>
            <h4>grow="مقدار دلخواهت به درصد"</h4>
            <h4>title="عنوان دلخواه"</h4>
        </div>
     <?php
    }
     function myshortcode($atts){
        extract(
            shortcode_atts( [
                'grow' => '80%',
    
                'title' => 'defualt',
            ], $atts)
        );
        $yourskillbar = '<div class="progressbar"><h3>'. $title .'<span>' . $grow . '</span></h3>
        <div class="bar"><span style="width: ' . $grow . ' !important"></span></div>
        </div>';
        return $yourskillbar;
      }
}
$glass_skill_bar_for_glass_theme = new GlassSkillbarForGlassTheme;


?>